Since there are so many pictures in this assignment, we thought that with only the 
notebook will be better because the campus doesn't allow us to send all the files because
the zip is past the limited size allowed for deliveries. 
